def functionofp2():
    print("this is file 2")