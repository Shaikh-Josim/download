def functionofp2():
    print("this is file 2")

def newFunOfP2():
    print("The p2 is also updated thanks")