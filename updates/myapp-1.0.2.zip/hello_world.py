import p2
from update import Updater
import os

class ApptoShowUpdate:
    def __init__(self) :
        self.current_version = '1.0.2'
        self.update_url = 'https://raw.githubusercontent.com/Shaikh-Josim/try/refs/heads/main/updates/update_info.json'
        self.download_dir = os.getcwd()
    
    def runApp(self):
        print("App running....\n")
        print("Hello, World!")
        p2.functionofp2()
        self.newFunOfUpdate()
        p2.newFunOfP2()
        ch = input("Want to check for update? Y or n:\t")
        if ch.capitalize() == 'Y':
            self.performUpdate()
            input("press enter to close the app")
        else:
            print("program is completed please enter to close")
            input()

    def newFunOfUpdate(self):
        print("This is the new function only available in version 1.0.2")
        print("if you are seeing this its means your app is updated also")
        print("Thanks for updating your app!!!")

    def performUpdate(self):
        updater = Updater(self.current_version, self.update_url, self.download_dir)
        download_url = updater.check_for_updates()
        if download_url:
            update_file = updater.download_update(download_url)
            updater.apply_update(update_file)

if __name__ == '__main__':
    app = ApptoShowUpdate()
    app.runApp()