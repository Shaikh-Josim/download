import requests
import zipfile
import os

class Updater:
    def __init__(self, current_version, update_url, download_dir):
        self.current_version = current_version
        self.update_url = update_url
        self.download_dir = download_dir

    def check_for_updates(self):
        response = requests.get(self.update_url)
        latest_version = response.json().get('version')
        if latest_version > self.current_version:
            print(f"Update available: {latest_version}")
            print("downloadlink:",response.json().get('download_url'))
            return response.json().get('download_url')
        else:
            print("No updates available.")
            return None

    def download_update(self, download_url):
        response = requests.get(download_url)
        update_file = os.path.join(self.download_dir, 'update.zip')
        with open(update_file, 'wb') as file:
            file.write(response.content)
        print("Update downloaded.")
        return update_file

    def apply_update(self, update_file):
        with zipfile.ZipFile(update_file, 'r') as zip_ref:
            zip_ref.extractall(self.download_dir)
        os.remove(update_file)
        print("Update applied.")

